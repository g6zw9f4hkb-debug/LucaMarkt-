const ADMIN_CODE="LUCA123";
let isAdmin=false;
const messages=JSON.parse(localStorage.getItem("ls_messages")||"[]");
const gallery=JSON.parse(localStorage.getItem("ls_gallery")||"[]");
const $=id=>document.getElementById(id);

function renderMessages(){
 const box=$("messages"); box.innerHTML="";
 messages.forEach(m=>{const d=document.createElement("div");d.className="msg"+(m.admin?" admin":"");d.innerHTML=`<strong>${escapeHtml(m.name)}${m.admin?" 👑":""}</strong><span class="time">${m.time}</span><div>${escapeHtml(m.text)}</div>`;box.appendChild(d)});
 box.scrollTop=box.scrollHeight;
}
function renderGallery(){
 const box=$("galleryGrid");box.innerHTML="";
 gallery.forEach((g,i)=>{const d=document.createElement("div");d.className="card";d.innerHTML=`<img src="${g.data}" alt="${escapeHtml(g.name)}"><div><span>${escapeHtml(g.name)}</span>${isAdmin?`<button class="delete" data-i="${i}">Löschen</button>`:""}</div>`;box.appendChild(d)});
 box.querySelectorAll(".delete").forEach(b=>b.onclick=()=>{gallery.splice(+b.dataset.i,1);save();renderGallery()});
}
function save(){localStorage.setItem("ls_messages",JSON.stringify(messages));localStorage.setItem("ls_gallery",JSON.stringify(gallery))}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}

$("send").onclick=send;
$("message").onkeydown=e=>{if(e.key==="Enter")send()};
function send(){const name=$("name").value.trim()||"Anonym";const text=$("message").value.trim();if(!text)return;messages.push({name,text,admin:isAdmin,time:new Date().toLocaleTimeString("de-DE",{hour:"2-digit",minute:"2-digit"})});save();$("message").value="";renderMessages()}
$("clearChat").onclick=()=>{if(isAdmin){messages.length=0;save();renderMessages()}else alert("Nur Luca darf den Chat leeren.")};

$("lucaBtn").onclick=()=>{$("modal").classList.remove("hidden");$("code").focus()};
$("close").onclick=()=>$("modal").classList.add("hidden");
$("login").onclick=()=>{if($("code").value===ADMIN_CODE){isAdmin=true;$("loginMsg").textContent="🚨 DER BOSS IST DA 🚨";$("lucaBtn").textContent="Luca 👑 · ADMIN";$("status").textContent="🟢 Luca ist Admin";$("modal").classList.add("hidden");renderGallery()}else $("loginMsg").textContent="❌ Falscher Code."};
$("file").onchange=e=>{const f=e.target.files[0];if(!f)return;if(!isAdmin){alert("Nur Luca darf Bilder hochladen.");e.target.value="";return}if(f.size>3*1024*1024){alert("Bitte ein Bild unter 3 MB verwenden.");return}const r=new FileReader();r.onload=()=>{gallery.push({name:f.name,data:r.result});save();renderGallery()};r.readAsDataURL(f);e.target.value=""};

renderMessages();renderGallery();

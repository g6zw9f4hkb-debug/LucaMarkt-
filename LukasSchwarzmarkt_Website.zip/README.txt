LUKASSCHWARZMARKT – Start

Diese Version läuft sofort als statische Website.
1. Entpacke die ZIP-Datei.
2. Öffne index.html per Doppelklick.
3. Admin-Code: LUCA123
4. Achtung: Chat und Bilder werden in dieser ersten Version nur im Browser (localStorage) gespeichert.
   Damit zwei Geräte denselben Chat sehen, braucht die Seite noch ein Online-Backend (z.B. Supabase).
5. Für eine kostenlose Veröffentlichung kannst du die drei Dateien bei einem statischen Hosting hochladen.
